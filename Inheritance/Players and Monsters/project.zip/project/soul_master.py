from project import DarkWizard


class SoulMaster(DarkWizard):
    pass
