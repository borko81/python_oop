from project import Hero


class Wizard(Hero):
    pass
