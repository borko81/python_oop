from project import Hero


class Elf(Hero):
    pass
