from project import Elf


class MuseElf(Elf):
    pass
