from project.beverage.beverage import Beverage

c = Beverage('NAME', 13, milliliters=15)
print(c.__dict__)